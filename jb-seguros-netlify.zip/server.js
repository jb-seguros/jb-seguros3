// Servidor Node (alternativa a Netlify: Render, Railway, tu computadora…). Usa exactamente el mismo manejador que la función de Netlify.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import web from './netlify/lib/web.mjs';

const PORT = process.env.PORT || 8787, DIR = path.dirname(fileURLToPath(import.meta.url));
process.env.DATA_DIR ||= path.join(DIR, 'data'); // fuera de Netlify, los datos del servidor se guardan en archivos (usa un disco persistente en tu hosting)
if (!process.env.OPENAI_API_KEY || !process.env.APP_TOKEN) console.warn('Aviso: faltan OPENAI_API_KEY y/o APP_TOKEN; /api/health?deep=1 indicará qué falta.');
const hits = new Map();
const limited = ip => { const n = Date.now(), e = hits.get(ip); if (!e || n > e[1]) { hits.set(ip, [1, n + 6e4]); return false; } return ++e[0] > 60; };

http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const pathname = new URL(req.url, 'http://x').pathname;
  if (req.method === 'GET' && (pathname === '/' || pathname === '/index.html')) {
    try { return res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }).end(await readFile(path.join(DIR, 'public', 'index.html'))); } catch { return res.writeHead(404).end(); }
  }
  if (!pathname.startsWith('/api/')) return res.writeHead(404).end();
  if (limited(req.socket.remoteAddress)) return res.writeHead(429, { 'Content-Type': 'application/json' }).end('{"ok":false,"error":{"kind":"limite","message":"Demasiadas solicitudes."}}');
  let body = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > 6e6) return res.writeHead(413).end(); body.push(c); }
  const r = await web(new Request('http://x' + req.url, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(body) }));
  res.writeHead(r.status, Object.fromEntries(r.headers)).end(Buffer.from(await r.arrayBuffer()));
}).listen(PORT, () => console.log('JB Seguros escuchando en :' + PORT));
