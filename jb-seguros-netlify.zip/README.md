# JB SEGUROS — CRM en Netlify (OpenAI + correo con Resend)

## 1. Variables de entorno (Netlify › Site configuration › Environment variables)
Solo las usan las funciones del servidor. **Nunca** con prefijos públicos (`VITE_`, `NEXT_PUBLIC_`). Después de cambiarlas: **Deploys › Trigger deploy**.

| Variable | Obligatoria | Para qué |
|---|---|---|
| `OPENAI_API_KEY` | sí | IA (asistente, análisis, lectura de PDF, borradores) |
| `APP_TOKEN` | sí | Contraseña entre el CRM y el servidor (inventa un texto largo). Se pega en Configuración › Inteligencia Artificial |
| `RESEND_API_KEY` | para correo | Clave de Resend |
| `EMAIL_FROM` | para correo | Remitente de un dominio verificado, ej. `JB SEGUROS <recordatorios@tudominio.com>` |
| `APP_URL` | para correo | Dirección de tu sitio, ej. `https://tu-sitio.netlify.app` (enlaces de baja y logo) |
| `RESEND_WEBHOOK_SECRET` | recomendada | Secreto `whsec_…` del webhook (confirma entregas, rebotes y quejas) |
| `OPENAI_MODEL` / `OPENAI_MODEL_PDF` | no | Por defecto `gpt-4o-mini` |

Si falta una, el CRM dice cuál (Configuración › Correo / Inteligencia Artificial). Nunca muestra su valor.

## 2. Verificar tu dominio de correo (Resend)
1. resend.com › Domains › Add Domain (el dominio desde el que enviarás).
2. Resend te da registros DNS (SPF/MX de envío y DKIM). Publícalos en el DNS de tu dominio (donde lo compraste).
3. Espera a que el dominio diga **Verified** (puede tardar minutos u horas).
4. Crea una API key (API Keys) y ponla en `RESEND_API_KEY`. `EMAIL_FROM` debe usar ese dominio.
5. Webhook: Resend › Webhooks › Add → URL `https://TU-SITIO/api/email/webhook`, eventos `email.sent`, `email.delivered`, `email.delivery_delayed`, `email.bounced`, `email.complained`. Copia el *Signing secret* a `RESEND_WEBHOOK_SECRET`.
6. En el CRM: Configuración › Correo › **Probar conexión** y **Enviar correo de prueba** (a tu propia dirección).

## 3. Despliegue (importante)
Debe hacerse **desde GitHub** (no arrastrando carpetas): Netlify instala dependencias, copia el visor PDF y publica las funciones, incluida la programada.
- `netlify.toml` ya define: build `npm run build` (copia pdf.js a `public/vendor/pdfjs`), funciones en `netlify/functions`.
- **Función programada** `netlify/functions/automatizaciones.mjs`: se ejecuta cada hora (en UTC, `@hourly`) y solo en el despliegue de **producción**. Calcula todo en hora de CDMX y envía desde la hora configurada (por defecto 9:00). Es seguro que corra varias veces: cada evento tiene clave de idempotencia. Límite de Netlify ≈ 30 s por ejecución: lo que no alcance continúa en la hora siguiente.
- Netlify Blobs (almacenamiento del servidor) funciona solo dentro de Netlify. Verifica en Configuración › Correo que «Almacenamiento del servidor» diga ✓.

## 4. Datos y migración (sin perder nada)
Tus datos siguen en el navegador (`localStorage`). El servidor guarda una **copia versionada** en Netlify Blobs (con respaldo de la versión anterior) para que las automatizaciones funcionen con el CRM cerrado.
1. Configuración › Correo › «Datos del CRM en el servidor» › **Subir ahora** y activa «Sincronizar automáticamente al guardar».
2. Si otro dispositivo subió una versión más reciente, el CRM avisa (conflicto) y **no sobrescribe**; tú eliges descargar (se guarda un respaldo local) o sobrescribir.
3. No se sobrescribe un servidor con clientes usando datos locales vacíos sin confirmación explícita.
No hay migración de esquema: los campos nuevos (`consentPromos`, documentos) tienen valores seguros por defecto (sin consentimiento).
Limitación: es una copia, no una base de datos relacional con varios usuarios. Para multiusuario real, el siguiente paso es PostgreSQL (Neon/Supabase).

## 5. Reglas de envío
- **Servicio** (pagos, renovaciones): se envían salvo rebote/queja.
- **Relación** (cumpleaños, agradecimiento, retomar contacto): no se envían a quien se dio de baja; a prospectos solo con consentimiento.
- **Promocional** (campañas, seguimiento a prospectos): solo con consentimiento («Acepta recibir promociones»), sin baja, con enlace de baja funcional (un clic, `List-Unsubscribe`).
- «Aceptado» = el proveedor lo recibió; «entregado»/«rebotado» llegan por webhook. Si no se sabe si un correo salió (error de red o 5xx), queda **«desconocido»** y **no se reenvía solo**.
- Asuntos sin importes ni datos financieros. Campañas: confirmación obligatoria; ≥ 10 destinatarios exigen escribir ENVIAR.
- Los recordatorios consultan el estado real del pago al enviar; un pago ya registrado no genera aviso.

## 6. Pruebas
- `npm test` — simuladas (OpenAI y Resend falsos, almacenamiento en memoria): lógica propia. **No** prueban el envío real.
- `npm run test:live` — reales contra OpenAI (necesita `.env` con `OPENAI_API_KEY`).
- `npm run test:live-email` — real con Resend (necesita `RESEND_API_KEY`, `EMAIL_FROM`, `APP_URL`, `APP_TOKEN` y `TEST_EMAIL_TO` = tu dirección). No envía a clientes.
- En el CRM: Configuración › Inteligencia Artificial › «Probar conexión» y «Probar lectura de PDF».

## 7. Límites conocidos
PDF ≤ 4 MB. El visor muestra las primeras 60 páginas. Seguimiento tras una cotización: no existe (el CRM no registra cotizaciones). Netlify limita el tiempo de las funciones según el plan.
